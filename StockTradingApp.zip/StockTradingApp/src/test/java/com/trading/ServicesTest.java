package com.trading;

import com.trading.exception.ListenerAlreadyExistException;
import com.trading.exception.StockAlreadyExistException;
import com.trading.model.Order;
import com.trading.model.PriceListener;
import com.trading.model.Stock;
import com.trading.service.OrderService;
import com.trading.service.PriceListenerService;
import com.trading.service.StockService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.*;
import static org.junit.Assert.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ServicesTest {

    @Autowired
    StockService stockService;
    @Autowired
    PriceListenerService priceListenerService;
    @Autowired
    OrderService orderService;

    @Test
    public void createStockTest() throws StockAlreadyExistException {
        Stock stock = new Stock("Test", 50d, 250);
        stockService.save(stock);

        assertNotNull("Stock shouldn't be null", stock.getId());
        assertThat(stock.getVolume(), equalTo(250));
        assertThat(stock.getPrice(), equalTo(50d));
        assertThat(stock.getName(), equalTo("Test"));
    }

    @org.junit.jupiter.api.Test
    void buyWhenVolumeEnough() throws ListenerAlreadyExistException, StockAlreadyExistException {
        Stock stock = new Stock("Test", 50d, 250);
        stockService.save(stock);
        assertNotNull("Stock shouldn't be null", stock.getId());

        PriceListener priceListener = new PriceListener("Test", 40, 100);
        priceListenerService.save(priceListener);
        assertNotNull("PriceListener shouldn't be null", priceListener.getId());

        Stock stockToUpdate = stockService.findByName("Test");
        stockToUpdate.setPrice(39d);
        stockService.save(stockToUpdate);

        Order order = orderService.findByName("Test");
        assertNotNull("Order shouldn't be null", order);
    }

    @org.junit.jupiter.api.Test
    void cannotBuyIfVolumeLack() throws ListenerAlreadyExistException, StockAlreadyExistException {
        Stock stock = new Stock("Test2", 50d, 250);
        stockService.save(stock);
        assertNotNull("Stock shouldn't be null", stock.getId());

        PriceListener priceListener = new PriceListener("Test2", 40, 300);
        priceListenerService.save(priceListener);
        assertNotNull("PriceListener shouldn't be null", priceListener.getId());

        Stock stockToUpdate = stockService.findByName("Test");
        stockToUpdate.setPrice(30d);
        stockService.save(stockToUpdate);

        Order order = orderService.findByName("Test");
        assertNull("Order shouldn't be null", order);
    }

    @org.junit.jupiter.api.Test
    void updateStockPrice() throws StockAlreadyExistException {
        Stock stock = new Stock("Test", 50d, 250);
        stockService.save(stock);
        assertNotNull("Stock shouldn't be null", stock.getId());

        Stock stockToUpdate = stockService.findByName("Test");
        stockToUpdate.setPrice(39d);
        stockService.save(stockToUpdate);
    }
}

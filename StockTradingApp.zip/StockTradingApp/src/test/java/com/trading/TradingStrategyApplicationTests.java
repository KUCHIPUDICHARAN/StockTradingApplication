package com.trading;

import com.trading.exception.ListenerAlreadyExistException;
import com.trading.exception.StockAlreadyExistException;
import com.trading.model.Order;
import com.trading.model.PriceListener;
import com.trading.model.Stock;
import com.trading.service.OrderService;
import com.trading.service.PriceListenerService;
import com.trading.service.StockService;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.*;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
class TradingStrategyApplicationTests {
	@MockBean
	StockService stockService;
	@MockBean
	OrderService orderService;

	@Autowired
	protected MockMvc mockMvc;

	@MockBean
	PriceListenerService priceListenerService;

	@Before
	public void setUp() {
		Mockito.reset(priceListenerService, stockService, orderService);
	}

	@Test
	void addAndRemoveListeners() throws Exception {
		// given
		PriceListener priceListener = new PriceListener("Apple", 43d, 340);
		// when
		when(priceListenerService.save(priceListener)).thenReturn(priceListener);

		//then
		mockMvc.perform(post("/addPriceListener?security=Apple&price=43&quantity=340")
				.contentType(APPLICATION_JSON_UTF8)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated());

		mockMvc.perform(post("/removePriceListener/IBM")
				.contentType(APPLICATION_JSON_UTF8)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}
}

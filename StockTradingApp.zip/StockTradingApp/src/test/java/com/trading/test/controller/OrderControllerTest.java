package com.trading.test.controller;

import com.trading.model.Order;
import com.trading.service.OrderService;
import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest
public class OrderControllerTest {

    @MockBean
    private OrderService orderService;

    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("Get all orders - Success")
    public void getAllOrdersTest() throws Exception {
        // Setup mocked service
        List<Order> allOrders = new ArrayList<>();
        Order mockOrder = new Order("Amazon", 50.00, "CLOSED", 1000);
        Order mockOrderTwo = new Order("ADP", 150.00, "CLOSED", 2000);
        Order mockOrderThree = new Order("HP", 250.00, "CLOSED", 3000);
        allOrders.add(mockOrder);
        allOrders.add(mockOrderTwo);
        allOrders.add(mockOrderThree);

        Mockito.when(orderService.findAll()).thenReturn(allOrders);

        // Execute the GET Request
        mockMvc.perform(MockMvcRequestBuilders.get("/getAllOrders"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON))

                //Validate the returned fields
                .andExpect(MockMvcResultMatchers.jsonPath("$", hasSize(3)))
                .andExpect(MockMvcResultMatchers.jsonPath("$[0].name", is("Amazon")))
                .andExpect(MockMvcResultMatchers.jsonPath("$[2].price", is(250.00)))
                .andExpect(MockMvcResultMatchers.jsonPath("$[1].quantity", is(2000)));
    }

}

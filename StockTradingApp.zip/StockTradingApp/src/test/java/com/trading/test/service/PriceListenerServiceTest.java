package com.trading.test.service;

import com.trading.exception.ListenerAlreadyExistException;
import com.trading.model.Order;
import com.trading.model.PriceListener;
import com.trading.repository.OrderRepository;
import com.trading.repository.PriceListenerRepository;
import com.trading.service.OrderService;
import com.trading.service.PriceListenerService;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.any;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest
public class PriceListenerServiceTest {

    @Autowired
    private PriceListenerService priceListenerService;

    @MockBean
    private PriceListenerRepository priceListenerRepository;

    @Test
    @DisplayName("Get PriceListener by security test")
    public void retrievePriceListenerBySecurityTest() {
        // Setup sample price listener
        PriceListener mockPriceListener = new PriceListener("ADP", 90.00, 1000);
        Mockito.when(priceListenerRepository.findBySecurity("ADP")).thenReturn(mockPriceListener);

        //Execute the service call
        PriceListener returnedListener = priceListenerService.findBySecurity("ADP");

        // Assert the response
        assertNotNull("Order shouldn't be null", returnedListener.getId());
        Assertions.assertSame(returnedListener, mockPriceListener);
        Assertions.assertEquals(returnedListener.getSecurity(), "ADP");
        Assertions.assertEquals(returnedListener.getQuantity(), 1000);
        Assertions.assertEquals(returnedListener.getPrice(), 90.00);
    }

    @Test
    @DisplayName("Test findAll price listeners")
    public void testFindAll() {
        // Setup sample price listeners
        List<PriceListener> allListeners = new ArrayList<>();
        PriceListener mockPriceListener = new PriceListener("IBM", 90.00, 100);
        PriceListener mockPriceListenerTwo = new PriceListener("ADP", 910.00, 1900);
        PriceListener mockPriceListenerThree = new PriceListener("HP", 190.00, 1090);
        allListeners.add(mockPriceListener);
        allListeners.add(mockPriceListenerTwo);
        allListeners.add(mockPriceListenerThree);

        Mockito.when(priceListenerRepository.findAll()).thenReturn(allListeners);

        // Execute the service call
        List<PriceListener> returnedListeners = priceListenerService.findAll();

        // Assert the response
        Assertions.assertEquals(3, returnedListeners.size());
    }

    @Test
    @DisplayName("Create Listener successfully")
    public void createPriceListenerTest() throws ListenerAlreadyExistException {
        // Setup sample price listener
        PriceListener mockPriceListener = new PriceListener("IBM", 90.00, 100);
        PriceListener mockPriceListener2 = new PriceListener("IBM", 90.00, 100);
        Mockito.when(priceListenerRepository.save(mockPriceListener)).thenReturn(mockPriceListener);

        //Execute the service call
        PriceListener returnedPriceListener = priceListenerService.save(mockPriceListener);

        // Assert the response
        assertNotNull("Order shouldn't be null", returnedPriceListener.getId());
        Assertions.assertSame(returnedPriceListener, mockPriceListener);
        Assertions.assertEquals(returnedPriceListener.getSecurity(), "IBM");
        Assertions.assertEquals(returnedPriceListener.getQuantity(), 100);
        Assertions.assertEquals(returnedPriceListener.getPrice(), 90.00);
    }

}

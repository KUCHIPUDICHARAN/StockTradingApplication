package com.trading.test.service;

import com.trading.exception.StockAlreadyExistException;
import com.trading.model.Order;
import com.trading.model.Stock;
import com.trading.repository.OrderRepository;
import com.trading.service.OrderService;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest
public class OrderServiceTest {

    @Autowired
    private OrderService orderService;

    @MockBean
    private OrderRepository orderRepository;

    @Test
    @DisplayName("Test findAll Orders")
    public void testFindAll() {
        // Setup sample Orders
        List<Order> orderList = new ArrayList<>();
        Order mockOrderOne = new Order("Amazon", 50.00, "CLOSED", 1000);
        Order mockOrderTwo = new Order("Apple", 150.00, "CLOSED", 2000);
        Order mockOrderThree = new Order("ADP", 20.00, "CLOSED", 1050);
        orderList.add(mockOrderOne);
        orderList.add(mockOrderTwo);
        orderList.add(mockOrderThree);

        Mockito.when(orderRepository.findAll()).thenReturn(orderList);

        // Execute the service call
        List<Order> returnedOrders = orderService.findAll();

        // Assert the response
        Assertions.assertEquals(3, returnedOrders.size());
    }

    @Test
    @DisplayName("Create Order successfully")
    public void createOrderTest() {
        // Setup sample order
        Order mockOrder = new Order("Amazon", 50.00, "CLOSED", 1000);

        //Execute the service call
        orderService.save(mockOrder);

        // Assert the response
        assertNotNull("Order shouldn't be null", mockOrder.getId());
        assertThat(mockOrder.getQuantity(), equalTo(1000));
        assertThat(mockOrder.getPrice(), equalTo(50.00));
        assertThat(mockOrder.getName(), equalTo("Amazon"));
    }

    @Test
    @DisplayName("Get Order By Name test")
    public void retrieveOrderByNameTest() {
        // Setup sample order
        Order mockOrder = new Order("ADP", 5.00, "CLOSED", 100);
        Mockito.when(orderRepository.findByName("ADP")).thenReturn(mockOrder);

        //Execute the service call
        Order returnedOrder = orderService.findByName("ADP");

        // Assert the response
        assertNotNull("Order shouldn't be null", mockOrder.getId());
        assertThat(returnedOrder.getQuantity(), equalTo(100));
        assertThat(returnedOrder.getPrice(), equalTo(5.00));
        assertThat(returnedOrder.getName(), equalTo("ADP"));
    }

}

package com.trading.test.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.trading.model.PriceListener;
import com.trading.model.Stock;
import com.trading.service.PriceListenerService;
import com.trading.service.execution.StockService;
import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest
public class PriceListenerControllerTest {

    @MockBean
    private PriceListenerService priceListenerService;

    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("Add priceListener - Success")
    public void addPriceListener() throws Exception {
        // Setup mocked service
        PriceListener mockPriceListener = new PriceListener("IBM", 90.00, 100);
        doReturn(mockPriceListener).when(priceListenerService).save(any());

        // Execute the POST Request
        mockMvc.perform(MockMvcRequestBuilders.post("/addPriceListener")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(mockPriceListener)))

                // Validate the response code and content
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON));
    }

    @Test
    @DisplayName("Remove priceListener - Success")
    public void removePriceListener() throws Exception {
        // Setup mocked service
        PriceListener mockPriceListener1 = new PriceListener("IBM", 90.00, 100);
        doNothing().when(priceListenerService).deleteBySecurity("IBM");

        // Execute the POST Request
        mockMvc.perform(MockMvcRequestBuilders.delete("/removePriceListener")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(mockPriceListener1)))

                // Validate the response code and content
                .andExpect(MockMvcResultMatchers.status().isOk());
    }


    @Test
    @DisplayName("Get all PriceListeners - Success")
    public void getAllListenersTest() throws Exception {
        // Setup mocked service
        List<PriceListener> allListeners = new ArrayList<>();
        PriceListener mockPriceListener = new PriceListener("IBM", 90.00, 100);
        PriceListener mockPriceListenerTwo = new PriceListener("ADP", 910.00, 1900);
        PriceListener mockPriceListenerThree = new PriceListener("HP", 190.00, 1090);
        allListeners.add(mockPriceListener);
        allListeners.add(mockPriceListenerTwo);
        allListeners.add(mockPriceListenerThree);

        Mockito.when(priceListenerService.findAll()).thenReturn(allListeners);

        // Execute the GET Request
        mockMvc.perform(MockMvcRequestBuilders.get("/getAllPriceListeners"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON))

                //Validate the returned fields
                .andExpect(MockMvcResultMatchers.jsonPath("$", hasSize(3)))
                .andExpect(MockMvcResultMatchers.jsonPath("$[0].security", is("IBM")))
                .andExpect(MockMvcResultMatchers.jsonPath("$[1].quantity", is(1900)))
                .andExpect(MockMvcResultMatchers.jsonPath("$[2].price", is(190.00)));
    }

    private String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }
}

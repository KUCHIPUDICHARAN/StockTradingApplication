package com.trading.test.service;

import com.trading.exception.StockAlreadyExistException;
import com.trading.model.Order;
import com.trading.model.Stock;
import com.trading.repository.StockRepository;
import com.trading.service.execution.StockService;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest
public class StockServiceTest {

    @Autowired
    StockService stockService;

    @MockBean
    private StockRepository stockRepository;

    @Test
    @DisplayName("Test findAll Stocks")
    public void testFindAllStock() {
        // Setup sample Stocks
        List<Stock> allStocks = new ArrayList<>();
        Stock mockStock = new Stock("IBM", 50.00, 1000);
        Stock mockStockTwo = new Stock("ADP", 150.00, 2000);
        Stock mockStockThree = new Stock("HP", 250.00, 3000);
        allStocks.add(mockStock);
        allStocks.add(mockStockTwo);
        allStocks.add(mockStockThree);

        Mockito.when(stockRepository.findAll()).thenReturn(allStocks);

        // Execute the service call
        List<Stock> returnedStocks = stockService.findAll();

        // Assert the response
        Assertions.assertEquals(3, returnedStocks.size());
    }

    @Test
    @DisplayName("Get Stock By Name test")
    public void retrieveStockByNameTest() {
        // Setup sample stock
        Stock mockStock = new Stock("IBM", 50.00, 1000);
        Mockito.when(stockRepository.findByName("IBM")).thenReturn(mockStock);

        //Execute the service call
        Stock returnedStock = stockService.findByName("IBM");

        // Assert the response
        assertNotNull("Order shouldn't be null", mockStock.getId());
        assertThat(returnedStock.getVolume(), equalTo(1000));
        assertThat(returnedStock.getPrice(), equalTo(50.00));
        assertThat(returnedStock.getName(), equalTo("IBM"));
    }

    @Test
    @DisplayName("Create Stock successfully")
    public void createStockTest() throws StockAlreadyExistException {
        // Setup sample stock
        Stock stock = new Stock("IBM", 50d, 250);

        //Execute the service call
        stockService.save(stock);

        // Assert the response
        assertNotNull("Stock shouldn't be null", stock.getId());
        assertThat(stock.getVolume(), equalTo(250));
        assertThat(stock.getPrice(), equalTo(50d));
        assertThat(stock.getName(), equalTo("IBM"));
    }

}

package com.trading.test.repository;

import com.trading.model.Stock;
import com.trading.repository.StockRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("test")
public class StockRepositoryTest {

    @Autowired
    private StockRepository stockRepository;

    @Before
    public void setUp(){
        stockRepository.deleteAll();
    }

    @Test
    public void testFindAll() {
        createStock();
        List<Stock> stockList = (List<Stock>) stockRepository.findAll();
        Assertions.assertEquals(1, stockList.size());
    }

    private void createStock() {
        Stock stock = new Stock();
        stock.setPrice(12.09);
        stock.setVolume(2);
        stock.setName("TATA");
        stockRepository.save(stock);
    }
}

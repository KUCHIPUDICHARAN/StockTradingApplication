package com.trading.test.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.trading.model.Stock;
import com.trading.service.execution.StockService;
import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest
public class StockControllerTest {

    @MockBean
    private StockService stockService;

    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("Get Stock IBM - Success")
    public void getStockByNameFound() throws Exception {
        // Setup mocked service
        Stock mockStock = new Stock("IBM", 50.00, 1000);
        Mockito.when(stockService.findByName("IBM")).thenReturn(mockStock);

        // Execute the GET Request
        mockMvc.perform(MockMvcRequestBuilders.get("/getStock?name=IBM"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON))

                //Validate the returned fields
                .andExpect(MockMvcResultMatchers.jsonPath("$.name", is("IBM")))
                .andExpect(MockMvcResultMatchers.jsonPath("$.price", is(50.00)))
                .andExpect(MockMvcResultMatchers.jsonPath("$.volume", is(1000)));
    }

    @Test
    @DisplayName("Get Stock IBM - Fail")
    public void getStockByNameNotFound() throws Exception {
        // Setup mocked service
        Stock sampleStock = new Stock("ADP", 50.00, 1000);

        Mockito.when(stockService.findByName("ADP")).thenReturn(sampleStock);

        // Execute the GET Request
        mockMvc.perform(MockMvcRequestBuilders.get("/getStock?name=IBM"))
                .andExpect(MockMvcResultMatchers.status().isNotFound());

    }

    @Test
    @DisplayName("Get all stocks - Success")
    public void getAllStocksTest() throws Exception {
        // Setup mocked service
        List<Stock> allStocks = new ArrayList<>();
        Stock mockStock = new Stock("IBM", 50.00, 1000);
        Stock mockStockTwo = new Stock("ADP", 150.00, 2000);
        Stock mockStockThree = new Stock("HP", 250.00, 3000);
        allStocks.add(mockStock);
        allStocks.add(mockStockTwo);
        allStocks.add(mockStockThree);

        Mockito.when(stockService.findAll()).thenReturn(allStocks);

        // Execute the GET Request
        mockMvc.perform(MockMvcRequestBuilders.get("/getAllStock"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON))

                //Validate the returned fields
                .andExpect(MockMvcResultMatchers.jsonPath("$", hasSize(3)))
                .andExpect(MockMvcResultMatchers.jsonPath("$[0].name", is("IBM")))
                .andExpect(MockMvcResultMatchers.jsonPath("$[2].price", is(250.00)))
                .andExpect(MockMvcResultMatchers.jsonPath("$[1].volume", is(2000)));
    }

    @Test
    @DisplayName("create Stock IBM - Success")
    public void createStock() throws Exception {
        // Setup mocked service
        Stock postStock = new Stock("IBM", 50.00, 1000);
        doNothing().when(stockService).save(any());

        // Execute the POST Request
        mockMvc.perform(MockMvcRequestBuilders.post("/addStock")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(postStock)))

                // Validate the response code and content
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON));
    }

    @Test
    @DisplayName("update Stock IBM - Fail")
    public void updateStock() throws Exception {
        // Setup mocked service
        Stock postStock = new Stock("IBM", 50.00, 1000);
        doNothing().when(stockService).updateStock("IBM", 48.00);

        // Execute the POST Request
        mockMvc.perform(MockMvcRequestBuilders.post("/updateStock")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(postStock)))

                // Validate the response code and content
                .andExpect(MockMvcResultMatchers.status().isNotFound());
    }

    private String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }
}

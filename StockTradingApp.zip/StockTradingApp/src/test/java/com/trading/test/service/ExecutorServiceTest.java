package com.trading.test.service;

import com.trading.exception.ListenerAlreadyExistException;
import com.trading.exception.StockAlreadyExistException;
import com.trading.model.Order;
import com.trading.model.PriceListener;
import com.trading.model.Stock;
import com.trading.repository.OrderRepository;
import com.trading.repository.PriceListenerRepository;
import com.trading.repository.StockRepository;
import com.trading.service.OrderService;
import com.trading.service.PriceListenerService;
import com.trading.service.execution.StockService;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest
public class ExecutorServiceTest {

    @Autowired
    StockService stockService;
    @Autowired
    PriceListenerService priceListenerService;
    @Autowired
    OrderService orderService;
    @Autowired
    OrderRepository orderRepository;
    @Autowired
    PriceListenerRepository priceListenerRepository;
    @Autowired
    StockRepository stockRepository;

    @Before
    public void setup() {
        stockRepository.deleteAll();
        orderRepository.deleteAll();
        priceListenerRepository.deleteAll();
    }

    @Test
    @DisplayName("BUY Stock successfully")
    public void buyWhenVolumeEnough() throws ListenerAlreadyExistException, StockAlreadyExistException {

        //Step 1 - Setup sample stock and save then verify it is saved?
        Stock stock = new Stock("Apple", 50d, 250);
        stockService.save(stock);
        assertNotNull("Stock shouldn't be null", stock.getId());

        //Step 2 - Setup price Listener for sample stock and save then verify it is saved?
        PriceListener priceListener = new PriceListener("Apple", 40d, 100);
        priceListenerService.save(priceListener);
        assertNotNull("PriceListener shouldn't be null", priceListener.getId());

        //Step 3 - update sample stock with new price then verify it is saved?
        Stock stockToUpdate = stockService.findByName("Apple");
        stockToUpdate.setPrice(39d);
        stockService.save(stockToUpdate);

        //Step 4 - finally verify order for the sample stock we created
        Order order = orderService.findByName("Apple");
        assertNotNull("Order shouldn't be null", order);
    }

    @Test
    @DisplayName("Unable to buy stock as volume is not enough")
    public void cannotBuyIfVolumeLack() throws ListenerAlreadyExistException, StockAlreadyExistException {
        Stock stock = new Stock("ADP", 50d, 250);
        stockService.save(stock);
        assertNotNull("Stock shouldn't be null", stock.getId());

        PriceListener priceListener = new PriceListener("ADP", 40d, 300);
        priceListenerService.save(priceListener);
        assertNotNull("PriceListener shouldn't be null", priceListener.getId());

        Stock stockToUpdate = stockService.findByName("ADP");
        stockToUpdate.setPrice(30d);
        stockService.save(stockToUpdate);

        Order order = orderService.findByName("ADP");
        assertNull("Order shouldn't be null", order);
    }

    @Test
    @DisplayName("update Stock successfully")
    public void updateStockPrice() throws StockAlreadyExistException {
        // Setup sample stock
        Stock stock = new Stock("Amazon", 50d, 250);
        stockService.save(stock);
        assertNotNull("Stock shouldn't be null", stock.getId());

        // verify update
        Stock stockToUpdate = stockService.findByName("Amazon");
        stockToUpdate.setPrice(39d);
        stockService.save(stockToUpdate);
    }
}

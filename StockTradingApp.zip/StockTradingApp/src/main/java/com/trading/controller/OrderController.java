package com.trading.controller;

import com.trading.model.Order;
import com.trading.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;

@RestController
public class OrderController {

    @Autowired
    private OrderService orderService;

    @RequestMapping(path = "/getAllOrders", method = RequestMethod.GET)
    public ResponseEntity getAllOrders() {

        Collection<Order> allOrders = orderService.findAll();
        return ResponseEntity.status(HttpStatus.OK).body(allOrders);
    }
}

package com.trading.controller;

import com.trading.exception.StockAlreadyExistException;
import com.trading.model.Stock;
import com.trading.service.execution.StockService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.websocket.server.PathParam;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Controller
public class StockController {

    private static final Logger logger = LoggerFactory.getLogger(StockController.class);

    @Autowired
    private StockService stockService;

    @RequestMapping(value = "/getStock", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity getStockByName(@PathParam("name") String name) {
        Optional<Stock> stock = Optional.ofNullable(stockService.findByName(name));
        if(stock.isPresent()){
            return ResponseEntity.status(HttpStatus.OK).body(stock);
        }
        return new ResponseEntity<HttpStatus>(HttpStatus.NOT_FOUND);
    }

    @RequestMapping(value = "/getAllStock", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity retrieveAllStock() {
        Collection<Stock> allStock = stockService.findAll();
        return ResponseEntity.status(HttpStatus.OK).body(allStock);
    }


    @RequestMapping(value = "/addStock", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity addNewStock(@RequestBody final Stock newStock) throws StockAlreadyExistException {
        logger.info("End point triggered to create new stock ");
        stockService.save(newStock);
            return ResponseEntity.status(HttpStatus.CREATED).body("stock successfully created with id " +newStock.getId());
    }

    @RequestMapping(value = "/updatePrice", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity updatePrice(@PathParam("name") String name, @PathParam("price") double price) throws Exception {
        logger.info("End point triggered to update existing stock ");
        stockService.updateStock(name, price);
        return ResponseEntity.status(HttpStatus.CREATED).body("stock successfully updated for " +name);
    }
}

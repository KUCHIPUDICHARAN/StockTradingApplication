package com.trading.controller;

import com.trading.exception.ListenerAlreadyExistException;
import com.trading.model.PriceListener;
import com.trading.service.PriceListenerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.websocket.server.PathParam;
import java.util.Collection;

@RestController
public class PriceListenerController {
    private static final Logger logger = LoggerFactory.getLogger(PriceListenerController.class);

    @Autowired
    PriceListenerService priceListenerService;

    /**
     * Adds specified price listener
     *
     * @param priceListener
     * @return HttpStatus.CREATED
     * @throws ListenerAlreadyExistException
     */
    @RequestMapping(path = "/addPriceListener", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity addPriceListener(@RequestBody final PriceListener priceListener) throws ListenerAlreadyExistException {
        logger.info("End point triggered to create new Price Listener ");
        priceListenerService.save(priceListener);
        return ResponseEntity.status(HttpStatus.CREATED).body("price listener successfully added " + priceListener.getSecurity());
    }

    /**
     * Removes specified price listener
     *
     * @param security
     * @return HttpStatus.OK
     */
    @RequestMapping(path = "/removePriceListener", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity removePriceListener(@PathParam("security") String security) {
        logger.info("End point triggered to remove existing Price Listener ");
        priceListenerService.deleteBySecurity(security);
        return new ResponseEntity<HttpStatus>(HttpStatus.OK);
    }

    /**
     * Returns all price listeners
     *
     * @return All Price Listeners
     */
    @RequestMapping(path = "/getAllPriceListeners", method = RequestMethod.GET)
    public ResponseEntity getAllPriceListeners() {

        Collection<PriceListener> allListeners = priceListenerService.findAll();
        return ResponseEntity.status(HttpStatus.OK).body(allListeners);
    }

}

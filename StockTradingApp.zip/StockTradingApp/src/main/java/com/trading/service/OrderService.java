package com.trading.service;

import com.trading.model.Order;
import com.trading.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderService {
    @Autowired
    private OrderRepository orderRepository;

    public Order findByName(String name) {
        return orderRepository.findByName(name);
    }

    public List<Order> findAll() {
        return (List<Order>) orderRepository.findAll();
    }

    public void save(Order order) {
        orderRepository.save(order);
    }
}

package com.trading.service;

import com.trading.exception.StockAlreadyExistException;
import com.trading.exception.StockNotFoundException;
import com.trading.model.Stock;
import com.trading.repository.StockRepo;
import com.trading.service.execution.ExecutionService;
import org.hibernate.FlushMode;
import org.hibernate.event.spi.PostUpdateEvent;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
public class StockService implements ExecutionService {

    private final StockRepo stockRepo;

    public StockService(StockRepo stockRepo) {
        this.stockRepo = stockRepo;
    }

    public Stock findByName(String name) {
        return stockRepo.findByName(name);
    }

    public void remove(Stock s) {
        stockRepo.delete(s);
    }

    public List<Stock> findAll() {
        List<Stock> stocks = new ArrayList<>();
        stockRepo.findAll().forEach(x->stocks.add(x));
        return stocks;
    }

    public void save(Stock s) throws StockAlreadyExistException {
        Stock check = stockRepo.findByName(s.getName());
        if(check != null && check.getId()!=s.getId()) {
                throw new StockAlreadyExistException();
        } else {
            stockRepo.save(s);
        }
    }

    @Override
    public void buy(String security, double price, int volume, PostUpdateEvent event) {
        Stock s = stockRepo.findByName(security);

        try {
            if (s == null) {
                throw new StockNotFoundException();
            }
            s.setVolume(s.getVolume() - volume);
            stockRepo.save(s);
            event.getSession().createNativeQuery(
                    "update stock " +
                            "set volume = :volume where id = :id ")
                    .setParameter("id", s.getId())
                    .setParameter("volume", s.getVolume())
                    .setFlushMode(FlushMode.MANUAL)
                    .executeUpdate();
        } catch (StockNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void sell(String security, double price, int volume) {

    }
}

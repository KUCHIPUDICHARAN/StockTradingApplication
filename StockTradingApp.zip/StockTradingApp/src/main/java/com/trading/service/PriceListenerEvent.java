package com.trading.service;

import com.trading.exception.VolumeNotEnoughException;
import com.trading.model.Order;
import com.trading.model.PriceListener;
import com.trading.model.Stock;
import org.hibernate.FlushMode;
import org.hibernate.event.spi.PostUpdateEvent;
import org.hibernate.event.spi.PostUpdateEventListener;
import org.hibernate.persister.entity.EntityPersister;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/*
 * This class implements a Hibernate listener
 *  that intercepts any update change on price.
 */
@Component
public class PriceListenerEvent implements PostUpdateEventListener {
    @Autowired
    private OrderService orderService;

    @Autowired
    private PriceListenerService priceListenerService;

    @Autowired
    private StockService stockService;

    public PriceListenerEvent() {
    }

    @Override
    public void onPostUpdate(PostUpdateEvent event) {
        final Object entity = event.getEntity();

        if(entity instanceof Stock) {
            Stock stock = (Stock) entity;

            PriceListener pl = priceListenerService.findBySecurity(stock.getName());
            // the stock is below for example - call buy
            if(pl != null && stock.getPrice()<pl.getPrice()) {
                Order o = new Order(stock.getName(), stock.getPrice(), "Closed", pl.getQuantity());
                orderService.save(o);

                try {
                    if (stock.getVolume() > pl.getQuantity()) {
                        stockService.buy(stock.getName(), stock.getPrice(), pl.getQuantity(), event);
                    } else {
                        throw new VolumeNotEnoughException();
                    }

                    event.getSession().createNativeQuery(
                            "insert into t_order " +
                                    "values(:id, :name, :position, :price, :quantity) ")
                            .setParameter("id", o.getId())
                            .setParameter("name", o.getName())
                            .setParameter("price", o.getPrice())
                            .setParameter("position", o.getPosition())
                            .setParameter("quantity", o.getQuantity())
                            .setFlushMode(FlushMode.MANUAL)
                            .executeUpdate();
                } catch (VolumeNotEnoughException e) {
                    e.printStackTrace();
                }
            }

        }
    }

    @Override
    public boolean requiresPostCommitHanding(EntityPersister entityPersister) {
        return false;
    }

}

package com.trading.service;

import com.sun.org.slf4j.internal.Logger;
import com.sun.org.slf4j.internal.LoggerFactory;
import com.trading.exception.VolumeNotEnoughException;
import com.trading.model.Order;
import com.trading.model.PriceListener;
import com.trading.model.Stock;
import com.trading.service.execution.StockService;
import org.hibernate.FlushMode;
import org.hibernate.event.spi.PostUpdateEvent;
import org.hibernate.event.spi.PostUpdateEventListener;
import org.hibernate.persister.entity.EntityPersister;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/*
 * This class implements a Hibernate listener
 *  that intercepts any update change on price.
 */
@Component
public class PriceListenerEvent implements PostUpdateEventListener {

    private static final Logger logger = LoggerFactory.getLogger(PriceListenerEvent.class);
    public static final String ORDER_CLOSED = "Closed";
    @Autowired
    private OrderService orderService;

    @Autowired
    private PriceListenerService priceListenerService;

    @Autowired
    private StockService stockService;

    public PriceListenerEvent() {
    }

    @Override
    public void onPostUpdate(PostUpdateEvent event) {
        final Object entity = event.getEntity();

        if (entity instanceof Stock) {
            Stock stock = (Stock) entity;

            PriceListener pl = priceListenerService.findBySecurity(stock.getName());
            // the stock is below for example - call buy
            if (pl != null && stock.getPrice() <= pl.getPrice()) {
                Order o = new Order(stock.getName(), stock.getPrice(), ORDER_CLOSED, pl.getQuantity());
                orderService.save(o);

                try {
                    if (stock.getVolume() >= pl.getQuantity()) {
                        stockService.buy(stock, pl.getQuantity(), event);
                    } else {
                        throw new VolumeNotEnoughException("Problem : the volume is not enough!");
                    }

                    event.getSession().createNativeQuery(
                            "insert into stock_order " +
                                    "values(:id, :name, :position, :price, :quantity) ")
                            .setParameter("id", o.getId())
                            .setParameter("name", o.getName())
                            .setParameter("price", o.getPrice())
                            .setParameter("position", o.getPosition())
                            .setParameter("quantity", o.getQuantity())
                            .setFlushMode(FlushMode.MANUAL)
                            .executeUpdate();
                } catch (VolumeNotEnoughException e) {
                    logger.error(e.getMessage());
                }
            }

        }
    }

    @Override
    public boolean requiresPostCommitHanding(EntityPersister entityPersister) {
        return false;
    }

}

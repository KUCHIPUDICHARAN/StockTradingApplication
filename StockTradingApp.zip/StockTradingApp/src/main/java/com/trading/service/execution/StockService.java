package com.trading.service.execution;

import com.trading.exception.EmptyStockException;
import com.trading.exception.StockAlreadyExistException;
import com.trading.model.Stock;
import com.trading.repository.StockRepository;
import org.hibernate.FlushMode;
import org.hibernate.event.spi.PostUpdateEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StockService implements ExecutionService {

    @Autowired
    private StockRepository stockRepository;

    public Stock findByName(String name) {
        return stockRepository.findByName(name);
    }

    public List<Stock> findAll() {
        return (List<Stock>) stockRepository.findAll();
    }

    public void save(Stock s) throws StockAlreadyExistException {
        Stock check = stockRepository.findByName(s.getName());
        if (check != null && check.getId() != s.getId()) {
            throw new StockAlreadyExistException("Error creating stock as Stock already exists with name {}" + s.getName());
        } else {
            stockRepository.save(s);
        }
    }

    @Override
    public void buy(Stock stock, int volumeToOrder, PostUpdateEvent event) {
        stock.setVolume(stock.getVolume() - volumeToOrder);
        stockRepository.save(stock);
        event.getSession().createNativeQuery(
                "update stock " +
                        "set volume = :volume where id = :id ")
                .setParameter("id", stock.getId())
                .setParameter("volume", stock.getVolume())
                .setFlushMode(FlushMode.MANUAL)
                .executeUpdate();
    }

    @Override
    public void updateStock(String name, double price) throws EmptyStockException {
        Stock stock = findByName(name);
        if (stock != null) {
            stock.setPrice(price);
            stockRepository.save(stock);
        } else {
            throw new EmptyStockException("Stock not exists with name {}" + name);
        }

    }

}

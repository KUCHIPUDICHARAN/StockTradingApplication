package com.trading.service.execution;

import org.hibernate.event.spi.PostUpdateEvent;
import org.springframework.stereotype.Service;

@Service
public interface ExecutionService {
    void buy(String security, double price, int volume, PostUpdateEvent event);
    void sell(String security, double price, int volume);
}

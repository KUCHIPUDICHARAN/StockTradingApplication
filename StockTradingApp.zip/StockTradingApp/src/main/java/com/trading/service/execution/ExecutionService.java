package com.trading.service.execution;

import com.trading.exception.EmptyStockException;
import com.trading.model.Stock;
import org.hibernate.event.spi.PostUpdateEvent;
import org.springframework.stereotype.Service;

@Service
public interface ExecutionService {
    void buy(Stock stock, int volume, PostUpdateEvent event);

    void updateStock(String name, double price) throws EmptyStockException;
}

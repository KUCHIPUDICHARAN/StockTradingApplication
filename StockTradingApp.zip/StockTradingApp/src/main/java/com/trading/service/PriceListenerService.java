package com.trading.service;

import com.trading.exception.ListenerAlreadyExistException;
import com.trading.model.PriceListener;
import com.trading.repository.PriceListenerRepo;
import org.springframework.stereotype.Service;

@Service
public class PriceListenerService {
    private final PriceListenerRepo priceListenerRepo;

    public PriceListenerService(PriceListenerRepo priceListenerRepo) {
        this.priceListenerRepo = priceListenerRepo;
    }

    public PriceListener findBySecurity(String name) {
        return priceListenerRepo.findBySecurity(name);
    }

    public PriceListener save(PriceListener priceListener) throws ListenerAlreadyExistException {
        if (priceListenerRepo.findBySecurity(priceListener.getSecurity()) != null) {
            throw new ListenerAlreadyExistException();
        }
        return priceListenerRepo.save(priceListener);
    }

    public void deleteBySecurity(String security) {
        priceListenerRepo.deleteBySecurity(security);
    }

    public void findAll() {
        priceListenerRepo.findAll();
    }
}

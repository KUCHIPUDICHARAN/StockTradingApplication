package com.trading.service;

import com.trading.exception.ListenerAlreadyExistException;
import com.trading.model.PriceListener;
import com.trading.repository.PriceListenerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Service
@Transactional(propagation = Propagation.REQUIRES_NEW)
public class PriceListenerService {
    @Autowired
    private PriceListenerRepository priceListenerRepository;

    public PriceListener findBySecurity(String name) {
        return priceListenerRepository.findBySecurity(name);
    }

    public PriceListener save(PriceListener priceListener) throws ListenerAlreadyExistException {
        if (priceListenerRepository.findBySecurity(priceListener.getSecurity()) != null) {
            throw new ListenerAlreadyExistException("PriceListener Already Exists For this Stock");
        }
        return priceListenerRepository.save(priceListener);
    }

    public void deleteBySecurity(String security) {
        priceListenerRepository.deleteBySecurity(security);
    }

    public List<PriceListener> findAll() {
        return (List<PriceListener>) priceListenerRepository.findAll();
    }
}

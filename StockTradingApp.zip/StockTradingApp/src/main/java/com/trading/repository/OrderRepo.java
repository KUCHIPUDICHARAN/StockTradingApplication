package com.trading.repository;

import com.trading.model.Order;
import org.springframework.data.repository.CrudRepository;

import javax.transaction.Transactional;

@Transactional
public interface OrderRepo extends CrudRepository<Order, Long> {
    Order findByName(String name);
}
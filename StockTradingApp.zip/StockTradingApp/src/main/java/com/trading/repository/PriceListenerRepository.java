package com.trading.repository;

import com.trading.model.PriceListener;
import org.springframework.data.repository.CrudRepository;

import javax.transaction.Transactional;

@Transactional
public interface PriceListenerRepository extends CrudRepository<PriceListener, Long> {
    // @Query("select p from PriceListener p where p.security=?1")
    PriceListener findBySecurity(String security);
    void deleteBySecurity(String security);
}
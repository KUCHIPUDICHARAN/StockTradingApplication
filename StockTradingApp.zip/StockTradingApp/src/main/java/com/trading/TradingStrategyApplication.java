package com.trading;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TradingStrategyApplication {

	public static void main(String[] args) {
		SpringApplication.run(TradingStrategyApplication.class, args);
	}

}

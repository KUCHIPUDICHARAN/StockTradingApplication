package com.trading.exception;

public class ListenerAlreadyExistException extends Exception {
    @Override
    public String getMessage() {
        return "Problem : Stock listener already exist!";
    }
}

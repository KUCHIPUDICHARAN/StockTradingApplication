package com.trading.exception;

public class ListenerAlreadyExistException extends Exception {

    public ListenerAlreadyExistException(final String message) {
        super(message);
    }
}

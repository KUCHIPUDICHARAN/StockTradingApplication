package com.trading.exception;

public class StockNotFoundException extends Exception {
    @Override
    public String getMessage() {
        return "Problem : Stock not Found!";
    }
}

package com.trading.exception;

public class StockNotFoundException extends Exception {

    public StockNotFoundException(final String message, final Throwable cause) {
        super(message,cause);
    }

    public StockNotFoundException(final String message) {
        super(message);
    }
}

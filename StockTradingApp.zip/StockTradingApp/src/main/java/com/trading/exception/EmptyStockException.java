package com.trading.exception;

public class EmptyStockException extends Exception {
    @Override
    public String getMessage() {
        return "Problem : the stock is empty!";
    }
}

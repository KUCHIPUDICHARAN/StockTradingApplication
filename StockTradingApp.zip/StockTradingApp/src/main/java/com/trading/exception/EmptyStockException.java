package com.trading.exception;

public class EmptyStockException extends Exception {

    public EmptyStockException(final String message) {
        super(message);
    }
}

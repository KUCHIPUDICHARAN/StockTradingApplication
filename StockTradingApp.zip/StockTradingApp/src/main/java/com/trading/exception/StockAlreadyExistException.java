package com.trading.exception;

public class StockAlreadyExistException extends Exception {
    @Override
    public String getMessage() {
        return "Problem : Stock already exist!";
    }
}

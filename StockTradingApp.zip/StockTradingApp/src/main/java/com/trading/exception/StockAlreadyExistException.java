package com.trading.exception;

public class StockAlreadyExistException extends Exception {

    public StockAlreadyExistException(final String message) {
        super(message);
    }
}

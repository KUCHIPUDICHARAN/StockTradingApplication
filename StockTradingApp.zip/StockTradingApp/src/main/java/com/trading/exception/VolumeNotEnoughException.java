package com.trading.exception;

public class VolumeNotEnoughException extends Exception {

    public VolumeNotEnoughException(final String message, final Throwable cause) {
        super(message,cause);
    }

    public VolumeNotEnoughException(final String message) {
        super(message);
    }
}
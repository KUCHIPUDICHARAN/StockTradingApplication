package com.trading.exception;

public class VolumeNotEnoughException extends Exception {
    @Override
    public String getMessage() {
        return "Problem : the volume is not enough!";
    }
}

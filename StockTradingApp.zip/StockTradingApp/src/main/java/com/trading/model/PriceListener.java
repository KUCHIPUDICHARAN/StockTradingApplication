package com.trading.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "price_listener")
public class PriceListener {

    @Id
    @Getter
    @Setter
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Getter
    @Setter
    private String security;

    @Getter
    @Setter
    private double price;

    @Getter@Setter
    private int quantity;

    public PriceListener() {
    }

    public PriceListener(String security, double price, int quantity) {
        this.security = security;
        this.price = price;
        this.quantity = quantity;
    }
}

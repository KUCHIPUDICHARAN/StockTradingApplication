package com.trading.model;


import com.sun.istack.NotNull;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "t_order")
public class Order {

    @Id
    @Getter@Setter
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Getter@Setter
    @NotNull
    private String name;

    @Getter@Setter
    @NotNull
    private Double price;

    @Getter@Setter
    @NotNull
    private String position = "Open";  // "Closed" otherwise

    @Getter@Setter
    private int quantity;

    public Order() {
    }

    public Order(String name, Double price, String position, int quantity) {
        this.name = name;
        this.price = price;
        this.position = position;
        this.quantity = quantity;
    }
}

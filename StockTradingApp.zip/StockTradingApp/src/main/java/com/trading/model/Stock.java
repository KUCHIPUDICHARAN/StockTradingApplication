package com.trading.model;

import com.sun.istack.NotNull;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "stock")
public class Stock {

    @Id
    @Getter@Setter
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Getter@Setter
    @NotNull
    @Column(unique = true)
    private String name;

    @Getter@Setter
    @NotNull
    private double price;

    @Getter@Setter
    @NotNull
    private int volume;

    public Stock() {
    }

    public Stock(String name, Double price, int volume) {
        this.name = name;
        this.price = price;
        this.volume = volume;
    }
}

package com.trading.rest;

import com.trading.exception.ListenerAlreadyExistException;
import com.trading.model.PriceListener;
import com.trading.service.PriceListenerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
public class PriceListenerController {

    @Autowired
    PriceListenerService priceListenerService;

    @PostMapping("/addPriceListener")
    @ResponseStatus(HttpStatus.CREATED)
        public String addPriceListener(String security, double price, int quantity) {
        try {
            priceListenerService.save(new PriceListener(security, price, quantity));
            return "price listener added";
        } catch (ListenerAlreadyExistException e) {
            return e.getMessage();
        }
    }

    @PostMapping("/removePriceListener/{security}")
    @ResponseStatus(HttpStatus.OK)
    public String removePriceListener(@PathVariable(value = "security") String security){
        priceListenerService.deleteBySecurity(security);
        return "price listener removed";
    }

}
